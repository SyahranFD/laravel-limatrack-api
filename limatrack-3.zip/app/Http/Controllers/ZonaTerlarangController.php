<?php

namespace App\Http\Controllers;

use App\Http\Requests\ZonaTerlarangRequest;
use App\Models\ZonaTerlarang;
use Illuminate\Http\Request;
use Illuminate\Support\Str;

class ZonaTerlarangController extends Controller
{
    public function store(ZonaTerlarangRequest $request)
    {
        $request->validated();

        $zonaTerlarang = ZonaTerlarang::create([
            'id' => 'zona-terlarang-'.Str::uuid(),
            'latitude' => $request->latitude,
            'longitude' => $request->longitude,
            'radius' => $request->radius,
        ]);

        return response([
            'data' => $zonaTerlarang,
        ], 201);
    }

    public function index()
    {
        $zonaTerlarang = ZonaTerlarang::all();

        return response([
            'data' => $zonaTerlarang,
        ], 200);
    }
}
