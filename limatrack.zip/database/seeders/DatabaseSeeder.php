<?php

namespace Database\Seeders;

// use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use App\Models\Pedagang;
use App\Models\User;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\Hash;

class DatabaseSeeder extends Seeder
{
    /**
     * Seed the application's database.
     */
    public function run(): void
    {
        User::create([
            'id' => 'user-'.fake()->uuid(),
            'nama_lengkap' => 'Rafa Syahran',
            'email' => 'fadhilrafa1@gmail.com',
            'password' => Hash::make('rafapass'),
            'role' => 'customer',
            'latitude' => '-6.753818894951011',
            'longitude' => '110.84275218710701',
        ]);

        User::create([
            'id' => 'user-'.fake()->uuid(),
            'nama_lengkap' => 'Rafa Syahran',
            'email' => 'fadhilrafa1@gmail.com',
            'password' => Hash::make('rafapass'),
            'role' => 'pedagang',
            'latitude' => '-6.754239742962566',
            'longitude' => '110.84305125340968',
        ]);

        User::create([
            'id' => 'user-'.fake()->uuid(),
            'nama_lengkap' => 'Rio Hermawan',
            'email' => 'rio@gmail.com',
            'password' => Hash::make('riopass'),
            'role' => 'customer',
        ]);

        $rio = User::create([
            'id' => 'user-'.fake()->uuid(),
            'nama_lengkap' => 'Rio Hermawan',
            'email' => 'rio@gmail.com',
            'password' => Hash::make('riopass'),
            'role' => 'pedagang',
            'latitude' => '-6.98181012492886',
            'longitude' => '110.45279892197568',
        ]);

        $pedagangRio = $rio->pedagang()->create([
            'id' => 'pedagang-'.fake()->uuid(),
            'user_id' => $rio->id,
            'nama_warung' => 'Siomay Batagor Rio',
            'nama_pedagang' => $rio->nama_lengkap,
            'banner' => 'https://www.niaga.asia/wp-content/uploads/2022/10/Screenshot_20221010-185531_Gallery-e1665399482853.jpg',
            'latitude' =>  $rio->latitude,
            'longitude' => $rio->longitude,
        ]);

        $pedagangRio->jajanan()->create([
            'id' => 'jajanan-'.fake()->uuid(),
            'nama_jajanan' => 'Siomay 5000',
            'harga' => 5000,
            'deskripsi' => 'Paket lengkap isi siomay, telur, tahu putih, kol, pare, dan bumbu kacang. Jika ada yang mau dirubah, tolong isi di catatan ya.',
            'foto' => 'https://i0.wp.com/resepkoki.id/wp-content/uploads/2020/03/Resep-Siomay-Bandung.jpg?fit=1859%2C1920&ssl=1',
            'kategori' => 'Jajanan Utama'
        ]);

        $pedagangRio->jajanan()->create([
            'id' => 'jajanan-'.fake()->uuid(),
            'nama_jajanan' => 'Siomay 3000',
            'harga' => 3000,
            'deskripsi' => 'Paket lengkap isi siomay, telur, tahu putih, kol, pare, dan bumbu kacang. Jika ada yang mau dirubah, tolong isi di catatan ya.',
            'foto' => 'https://i0.wp.com/resepkoki.id/wp-content/uploads/2020/03/Resep-Siomay-Bandung.jpg?fit=1859%2C1920&ssl=1',
            'kategori' => 'Lainnya'
        ]);

        $pedagangRio->jajanan()->create([
            'id' => 'jajanan-'.fake()->uuid(),
            'nama_jajanan' => 'Siomay 2000',
            'harga' => 2000,
            'deskripsi' => 'Paket lengkap isi siomay, telur, tahu putih, kol, pare, dan bumbu kacang. Jika ada yang mau dirubah, tolong isi di catatan ya.',
            'foto' => 'https://i0.wp.com/resepkoki.id/wp-content/uploads/2020/03/Resep-Siomay-Bandung.jpg?fit=1859%2C1920&ssl=1',
            'kategori' => 'Lainnya'
        ]);
        
        $pedagangRio->jajanan()->create([
            'id' => 'jajanan-'.fake()->uuid(),
            'nama_jajanan' => 'Batagor 5000',
            'harga' => 5000,
            'deskripsi' => 'Jika ada yang mau dirubah, tolong isi di catatan ya.',
            'foto' => 'https://cdn0-production-images-kly.akamaized.net/hjyQ1Kv6CwzCSNmNNYcevSRv-Ok=/1200x675/smart/filters:quality(75):strip_icc():format(jpeg)/kly-media-production/medias/1364565/original/091028300_1475593576-batagor.jpg',
            'kategori' => 'Jajanan Utama'
        ]);

        $pedagangRio->jajanan()->create([
            'id' => 'jajanan-'.fake()->uuid(),
            'nama_jajanan' => 'Batagor 3000',
            'harga' => 3000,
            'deskripsi' => 'Jika ada yang mau dirubah, tolong isi di catatan ya.',
            'foto' => 'https://cdn0-production-images-kly.akamaized.net/hjyQ1Kv6CwzCSNmNNYcevSRv-Ok=/1200x675/smart/filters:quality(75):strip_icc():format(jpeg)/kly-media-production/medias/1364565/original/091028300_1475593576-batagor.jpg',
            'kategori' => 'Lainnya'
        ]);

        $pedagangRio->jajanan()->create([
            'id' => 'jajanan-'.fake()->uuid(),
            'nama_jajanan' => 'Batagor 2000',
            'harga' => 2000,
            'deskripsi' => 'Jika ada yang mau dirubah, tolong isi di catatan ya.',
            'foto' => 'https://cdn0-production-images-kly.akamaized.net/hjyQ1Kv6CwzCSNmNNYcevSRv-Ok=/1200x675/smart/filters:quality(75):strip_icc():format(jpeg)/kly-media-production/medias/1364565/original/091028300_1475593576-batagor.jpg',
            'kategori' => 'Lainnya'
        ]);

        User::factory()
        ->has(
            Pedagang::factory()
                ->state(function (array $attributes, User $user) {
                    return [
                        'nama_warung' => 'Batagor Pak Riot',
                        'nama_pedagang' => $user->nama_lengkap,
                        'banner' => 'https://kuninganmass.com/wp-content/uploads/2021/09/IMG-20210909-WA0056.jpg',
                        'latitude' => $user->latitude,
                        'longitude' => $user->longitude,
                    ];
                })
        )
        ->create([
            'role' => 'pedagang',
            'latitude' => '-6.75392669750156',
            'longitude' => '110.84386271712118',
        ]);

        User::factory()
        ->has(
            Pedagang::factory()
                ->state(function (array $attributes, User $user) {
                    return [
                        'nama_warung' => 'Cilor Mas Pri',
                        'nama_pedagang' => $user->nama_lengkap,
                        'banner' => 'https://kuninganmass.com/wp-content/uploads/2021/09/IMG-20210909-WA0056.jpg',
                        'latitude' => $user->latitude,
                        'longitude' => $user->longitude,
                    ];
                })
        )
        ->create([
            'role' => 'pedagang',
            'latitude' => '-6.75192669750156',
            'longitude' => '110.84186271712118',
        ]);

        User::factory()
        ->has(
            Pedagang::factory()
                ->state(function (array $attributes, User $user) {
                    return [
                        'nama_warung' => 'Siomay Pak Fuad',
                        'nama_pedagang' => $user->nama_lengkap,
                        'banner' => 'https://kuninganmass.com/wp-content/uploads/2021/09/IMG-20210909-WA0056.jpg',
                        'latitude' => $user->latitude,
                        'longitude' => $user->longitude,
                    ];
                })
        )
        ->create([
            'role' => 'pedagang',
            'latitude' => '-6.75392669750156',
            'longitude' => '110.84186271712118',
        ]);

        User::factory()
            ->has(
                Pedagang::factory()
                    ->state(function (array $attributes, User $user) {
                        return [
                            'nama_warung' => 'Siomay Pak Somad',
                            'nama_pedagang' => $user->nama_lengkap,
                            'banner' => 'https://kuninganmass.com/wp-content/uploads/2021/09/IMG-20210909-WA0056.jpg',
                            'latitude' => $user->latitude,
                            'longitude' => $user->longitude,
                        ];
                    })
            )
            ->create([
                'role' => 'pedagang',
                'latitude' => '-6.75392669750156',
                'longitude' => '110.84286271712118',
            ]);
    }
}
